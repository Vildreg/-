#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/opt/project-manager"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Запусти установщик через sudo: sudo $0" >&2
  exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker Engine не найден. Сначала установи Docker Engine и Docker Compose plugin:" >&2
  echo "https://docs.docker.com/engine/install/ubuntu/" >&2
  exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose v2 не найден. Установи пакет docker-compose-plugin:" >&2
  echo "https://docs.docker.com/compose/install/linux/" >&2
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  echo "Docker daemon недоступен. Проверь: sudo systemctl enable --now docker" >&2
  exit 1
fi

mkdir -p "$INSTALL_DIR/app" "$INSTALL_DIR/projects" "$INSTALL_DIR/diagnostics"
cp -a "$SCRIPT_DIR/app/." "$INSTALL_DIR/app/"
cp "$SCRIPT_DIR/Dockerfile" "$SCRIPT_DIR/docker-compose.yml" "$SCRIPT_DIR/requirements.txt" "$SCRIPT_DIR/.dockerignore" "$SCRIPT_DIR/PROJECT_FORMAT.md" "$SCRIPT_DIR/project-template.zip" "$INSTALL_DIR/"
chmod 700 "$INSTALL_DIR"

if [[ ! -f "$INSTALL_DIR/.env" ]]; then
  ADMIN_PASSWORD="$(openssl rand -hex 20 2>/dev/null || python3 -c 'import secrets; print(secrets.token_hex(20))')"
  SESSION_SECRET="$(openssl rand -hex 48 2>/dev/null || python3 -c 'import secrets; print(secrets.token_hex(48))')"
  DOCKER_GID="$(stat -c '%g' /var/run/docker.sock)"
  cat > "$INSTALL_DIR/.env" <<EOF
ADMIN_USERNAME=admin
ADMIN_PASSWORD=$ADMIN_PASSWORD
SESSION_SECRET=$SESSION_SECRET
DOCKER_GID=$DOCKER_GID
PORT=8787
MAX_UPLOAD_BYTES=262144000
MAX_EXTRACTED_BYTES=2147483648
STARTUP_VERIFY_DELAY_SECONDS=3
DIAGNOSTICS_KEEP_PER_PROJECT=20
SESSION_COOKIE_SECURE=0
TELEGRAM_BOT_TOKEN=
ADMIN_TELEGRAM_IDS=
EOF
  chmod 600 "$INSTALL_DIR/.env"
  echo
  echo "Сгенерирован пароль администратора:"
  echo "Логин: admin"
  echo "Пароль: $ADMIN_PASSWORD"
  echo "Сохрани его. Он также записан в $INSTALL_DIR/.env"
  echo
else
  chmod 600 "$INSTALL_DIR/.env"
  if ! grep -q '^DOCKER_GID=' "$INSTALL_DIR/.env"; then
    echo "DOCKER_GID=$(stat -c '%g' /var/run/docker.sock)" >> "$INSTALL_DIR/.env"
  fi
  grep -q '^TELEGRAM_BOT_TOKEN=' "$INSTALL_DIR/.env" || echo 'TELEGRAM_BOT_TOKEN=' >> "$INSTALL_DIR/.env"
  grep -q '^ADMIN_TELEGRAM_IDS=' "$INSTALL_DIR/.env" || echo 'ADMIN_TELEGRAM_IDS=' >> "$INSTALL_DIR/.env"
  grep -q '^STARTUP_VERIFY_DELAY_SECONDS=' "$INSTALL_DIR/.env" || echo 'STARTUP_VERIFY_DELAY_SECONDS=3' >> "$INSTALL_DIR/.env"
  grep -q '^DIAGNOSTICS_KEEP_PER_PROJECT=' "$INSTALL_DIR/.env" || echo 'DIAGNOSTICS_KEEP_PER_PROJECT=20' >> "$INSTALL_DIR/.env"
  echo "Существующий .env сохранён. Пароль не менялся."
fi
chown 10001:10001 "$INSTALL_DIR/projects" "$INSTALL_DIR/diagnostics"
chmod 700 "$INSTALL_DIR/projects" "$INSTALL_DIR/diagnostics"

cd "$INSTALL_DIR"
docker compose -p ubuntu-project-manager up -d --build

echo
echo "Установка завершена. Панель слушает только 127.0.0.1:8787 на сервере."
echo "С компьютера подключись SSH-туннелем:"
echo "  ssh -L 8787:127.0.0.1:8787 USER@SERVER_IP"
echo "Затем открой: http://127.0.0.1:8787"
echo "Папка установки: $INSTALL_DIR"
