import logging
import os
import signal
import sys
import time


def required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value or value.upper() in {"CHANGE_ME", "CHANGEME", "REPLACE_ME", "TODO"}:
        raise RuntimeError(f"Не задана обязательная переменная {name}. Заполни её в Project Manager → Переменные.")
    return value


def main() -> None:
    logging.basicConfig(
        level=os.getenv("LOG_LEVEL", "INFO").upper(),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        stream=sys.stdout,
    )
    # Получаем обязательные настройки только из .pm.env, не вшиваем секреты в код.
    bot_token = required_env("BOT_TOKEN")
    admin_id = required_env("ADMIN_ID")
    logging.info("Приложение успешно запущено; ADMIN_ID=%s", admin_id)
    logging.info("BOT_TOKEN загружен (значение намеренно не выводится)")

    # Замени этот цикл реальной логикой приложения / запуском Telegram-бота.
    stopping = False

    def stop_handler(_signum, _frame):
        nonlocal stopping
        stopping = True

    signal.signal(signal.SIGTERM, stop_handler)
    signal.signal(signal.SIGINT, stop_handler)
    while not stopping:
        time.sleep(1)
    logging.info("Получен сигнал остановки, завершаю работу")


if __name__ == "__main__":
    main()
