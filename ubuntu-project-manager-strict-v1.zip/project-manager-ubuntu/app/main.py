from __future__ import annotations

import asyncio
import hmac
import json
import os
import re
import secrets
import shlex
import shutil
import subprocess
import tempfile
import time
import uuid
import zipfile
from datetime import datetime, timezone
from contextlib import asynccontextmanager
from pathlib import Path, PurePosixPath
from typing import Any

import yaml

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from starlette.middleware.sessions import SessionMiddleware

APP_DIR = Path(__file__).resolve().parent
TEMPLATE_DIR = APP_DIR / "templates"
PROJECTS_DIR = Path(os.environ.get("PROJECTS_DIR", "/opt/project-manager/projects")).resolve()
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")
SESSION_SECRET = os.environ.get("SESSION_SECRET", "")
SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "0") == "1"
MAX_UPLOAD_BYTES = int(os.environ.get("MAX_UPLOAD_BYTES", str(250 * 1024 * 1024)))
MAX_EXTRACTED_BYTES = int(os.environ.get("MAX_EXTRACTED_BYTES", str(2 * 1024 * 1024 * 1024)))
MAX_ARCHIVE_FILES = int(os.environ.get("MAX_ARCHIVE_FILES", "15000"))
DIAGNOSTICS_DIR = Path(os.environ.get("DIAGNOSTICS_DIR", "/opt/project-manager/diagnostics")).resolve()
STARTUP_VERIFY_DELAY_SECONDS = float(os.environ.get("STARTUP_VERIFY_DELAY_SECONDS", "3"))
DIAGNOSTICS_KEEP_PER_PROJECT = max(1, int(os.environ.get("DIAGNOSTICS_KEEP_PER_PROJECT", "20")))

if not ADMIN_PASSWORD or len(SESSION_SECRET) < 32:
    raise RuntimeError("ADMIN_PASSWORD and a SESSION_SECRET of at least 32 characters must be configured")

PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
DIAGNOSTICS_DIR.mkdir(parents=True, exist_ok=True)

@asynccontextmanager
async def lifespan(app: FastAPI):
    from app.telegram_bot import start_bot, stop_bot
    telegram_application = await start_bot()
    app.state.telegram_application = telegram_application
    try:
        yield
    finally:
        await stop_bot(telegram_application)


app = FastAPI(title="Ubuntu Project Manager", docs_url=None, redoc_url=None, lifespan=lifespan)
app.add_middleware(
    SessionMiddleware,
    secret_key=SESSION_SECRET,
    session_cookie="pm_session",
    max_age=12 * 60 * 60,
    same_site="strict",
    https_only=SESSION_COOKIE_SECURE,
)

# Jobs are intentionally in-memory: after a panel restart, running containers remain
# managed by Docker, while a stale progress indicator is discarded.
JOBS: dict[str, dict[str, Any]] = {}
PROJECT_LOCKS: dict[str, asyncio.Lock] = {}
LOGIN_FAILURES: dict[str, list[float]] = {}

# Project Format v1 is intentionally strict: the manager only operates these files.
PROJECT_MANIFEST = "pm-project.json"
PROJECT_COMPOSE = "compose.yaml"
PROJECT_ENV = ".pm.env"
PROJECT_ENV_EXAMPLE = ".pm.env.example"
ENV_KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
SERVICE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,62}$")
RESERVED_ENV_PREFIXES = ("COMPOSE_", "DOCKER_")
PLACEHOLDER_VALUES = {"", "CHANGE_ME", "CHANGEME", "REPLACE_ME", "YOUR_VALUE", "YOUR_TOKEN", "TODO", "__SET_ME__"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def safe_slug(value: str) -> str:
    value = value.strip().lower()
    out = []
    for char in value:
        if char.isascii() and (char.isalnum() or char in "-_"):
            out.append(char)
        elif char.isspace() or char in ".:/\\":
            out.append("-")
    slug = "".join(out).strip("-_")
    while "--" in slug:
        slug = slug.replace("--", "-")
    return slug[:48].strip("-_")


def project_path(slug: str) -> Path:
    if not slug or safe_slug(slug) != slug:
        raise HTTPException(status_code=400, detail="Некорректное имя проекта")
    path = (PROJECTS_DIR / slug).resolve()
    if path.parent != PROJECTS_DIR:
        raise HTTPException(status_code=400, detail="Некорректный путь проекта")
    if not path.is_dir():
        raise HTTPException(status_code=404, detail="Проект не найден")
    return path


def read_metadata(path: Path) -> dict[str, Any]:
    meta_path = path / ".project-manager.json"
    if meta_path.exists():
        try:
            data = json.loads(meta_path.read_text("utf-8"))
            if isinstance(data, dict):
                return data
        except (OSError, json.JSONDecodeError):
            pass
    try:
        spec = read_project_manifest(path)
    except (ValueError, OSError):
        spec = {}
    return {
        "name": spec.get("name") or path.name,
        "slug": path.name,
        "compose_file": PROJECT_COMPOSE,
        "created_at": "",
        "format_version": 1,
        "env_file": PROJECT_ENV,
        "app_service": spec.get("app_service", "app"),
        "required_env": spec.get("required_env", []),
    }


def read_project_manifest(path: Path) -> dict[str, Any]:
    manifest_path = path / PROJECT_MANIFEST
    if not manifest_path.is_file() or manifest_path.is_symlink():
        raise ValueError(f"Не найден обязательный файл {PROJECT_MANIFEST}")
    try:
        spec = json.loads(manifest_path.read_text("utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Файл {PROJECT_MANIFEST} должен содержать корректный JSON: {exc}") from exc
    if not isinstance(spec, dict):
        raise ValueError(f"{PROJECT_MANIFEST}: ожидается JSON-объект")
    allowed = {"format_version", "name", "description", "compose_file", "env_file", "env_example_file", "app_service", "required_env"}
    unknown = sorted(set(spec) - allowed)
    if unknown:
        raise ValueError(f"{PROJECT_MANIFEST}: неизвестные поля: {', '.join(unknown)}")
    if type(spec.get("format_version")) is not int or spec.get("format_version") != 1:
        raise ValueError(f"Поддерживается только целочисленный format_version: 1 в {PROJECT_MANIFEST}")
    if not isinstance(spec.get("name"), str) or not spec["name"].strip() or len(spec["name"].strip()) > 80:
        raise ValueError(f"{PROJECT_MANIFEST}: поле name обязательно (до 80 символов)")
    fixed_files = {"compose_file": PROJECT_COMPOSE, "env_file": PROJECT_ENV, "env_example_file": PROJECT_ENV_EXAMPLE}
    for key, expected in fixed_files.items():
        if spec.get(key) != expected:
            raise ValueError(f"{PROJECT_MANIFEST}: поле {key} должно быть строго равно {expected}")
    app_service = spec.get("app_service")
    if not isinstance(app_service, str) or not SERVICE_RE.fullmatch(app_service):
        raise ValueError(f"{PROJECT_MANIFEST}: app_service должен быть корректным именем сервиса Docker Compose")
    required = spec.get("required_env", [])
    if not isinstance(required, list) or any(not isinstance(item, str) or not ENV_KEY_RE.fullmatch(item) for item in required):
        raise ValueError(f"{PROJECT_MANIFEST}: required_env должен быть списком имён переменных")
    if len(required) != len(set(required)):
        raise ValueError(f"{PROJECT_MANIFEST}: required_env содержит повторяющиеся переменные")
    return spec


def parse_env_file(path: Path) -> dict[str, str]:
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"Не найден обычный файл {path.name}")
    if path.stat().st_size > 128 * 1024:
        raise ValueError(f"{path.name} превышает лимит 128 КБ")
    result: dict[str, str] = {}
    for line_number, raw in enumerate(path.read_text("utf-8-sig").splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export ") or "=" not in line:
            raise ValueError(f"{path.name}:{line_number}: используйте формат KEY=value без export")
        key, value = line.split("=", 1)
        key = key.strip()
        if not ENV_KEY_RE.fullmatch(key):
            raise ValueError(f"{path.name}:{line_number}: некорректное имя переменной")
        if key.startswith(RESERVED_ENV_PREFIXES):
            raise ValueError(f"{path.name}:{line_number}: переменные DOCKER_* и COMPOSE_* зарезервированы менеджером")
        if key in result:
            raise ValueError(f"{path.name}:{line_number}: переменная {key} указана несколько раз")
        if "\x00" in value:
            raise ValueError(f"{path.name}:{line_number}: нулевой байт запрещён")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] == "'":
            value = value[1:-1].replace("\\'", "'").replace("\\\\", "\\")
        elif len(value) >= 2 and value[0] == value[-1] == '"':
            value = value[1:-1].replace('\\"', '"').replace("\\\\", "\\")
        result[key] = value
    return result


def ensure_private_env_ignored(path: Path) -> None:
    """Keep the manager-owned secret file out of Docker build contexts and Git."""
    protected = {PROJECT_ENV, f"{PROJECT_ENV}.tmp", f"!{PROJECT_ENV}", f"!{PROJECT_ENV}.tmp"}
    for filename in (".dockerignore", ".gitignore"):
        ignore_path = path / filename
        if ignore_path.is_symlink():
            raise ValueError(f"{filename} не может быть символической ссылкой")
        try:
            existing = ignore_path.read_text("utf-8") if ignore_path.exists() else ""
        except OSError as exc:
            raise ValueError(f"Не удалось проверить {filename}: {exc}") from exc
        lines = [line for line in existing.splitlines() if line.strip() not in protected]
        # Put the deny rules last, so a later negation in an uploaded ignore file
        # cannot accidentally re-include the manager-owned secret file.
        lines.extend([PROJECT_ENV, f"{PROJECT_ENV}.tmp"])
        updated = "\n".join(lines).rstrip() + "\n"
        if updated != existing:
            ignore_path.write_text(updated, encoding="utf-8")


def validate_project_layout(path: Path, *, create_env: bool = False) -> dict[str, Any]:
    """Validate the strict Project Manager v1 layout and optionally create its private env file."""
    spec = read_project_manifest(path)
    compose_path = path / PROJECT_COMPOSE
    env_example = path / PROJECT_ENV_EXAMPLE
    if not compose_path.is_file() or compose_path.is_symlink():
        raise ValueError(f"Не найден обязательный файл {PROJECT_COMPOSE}")
    if not env_example.is_file() or env_example.is_symlink():
        raise ValueError(f"Не найден обязательный файл {PROJECT_ENV_EXAMPLE}")
    if (path / PROJECT_ENV).exists() and create_env:
        raise ValueError(f"Не добавляй {PROJECT_ENV} в ZIP. Менеджер создаёт этот приватный файл из {PROJECT_ENV_EXAMPLE}")
    example_values = parse_env_file(env_example)
    missing_template_keys = [key for key in spec.get("required_env", []) if key not in example_values]
    if missing_template_keys:
        raise ValueError(f"В {PROJECT_ENV_EXAMPLE} отсутствуют обязательные переменные: {', '.join(missing_template_keys)}")
    try:
        compose_doc = yaml.safe_load(compose_path.read_text("utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise ValueError(f"{PROJECT_COMPOSE}: некорректный YAML: {exc}") from exc
    services = compose_doc.get("services") if isinstance(compose_doc, dict) else None
    if not isinstance(services, dict) or not services:
        raise ValueError(f"{PROJECT_COMPOSE}: требуется непустой раздел services")
    app_service = spec["app_service"]
    service = services.get(app_service)
    if not isinstance(service, dict):
        raise ValueError(f"{PROJECT_COMPOSE}: сервис app_service={app_service!r} не найден в services")
    env_file = service.get("env_file")
    env_files: list[str] = []
    if isinstance(env_file, str):
        env_files = [env_file]
    elif isinstance(env_file, list):
        for item in env_file:
            if isinstance(item, str):
                env_files.append(item)
            elif isinstance(item, dict) and isinstance(item.get("path"), str):
                env_files.append(item["path"])
    normalized_env_files = [item.removeprefix("./") for item in env_files]
    if normalized_env_files != [PROJECT_ENV]:
        raise ValueError(f"В сервисе {app_service!r} должен быть указан только один env_file: {PROJECT_ENV}")
    if create_env:
        env_path = path / PROJECT_ENV
        shutil.copyfile(env_example, env_path)
        env_path.chmod(0o600)
    elif not (path / PROJECT_ENV).is_file():
        raise ValueError(f"Не найден {PROJECT_ENV}. Добавь его через раздел «Переменные» или восстанови из {PROJECT_ENV_EXAMPLE}")
    env_path = path / PROJECT_ENV
    parse_env_file(env_path)
    env_path.chmod(0o600)
    ensure_private_env_ignored(path)
    return spec


def find_compose_file(path: Path) -> str | None:
    # Legacy loose Compose uploads are intentionally not recognized by v1.
    return PROJECT_COMPOSE if (path / PROJECT_COMPOSE).is_file() and (path / PROJECT_MANIFEST).is_file() else None


def compose_base(slug: str, path: Path | None = None) -> list[str]:
    directory = path or project_path(slug)
    validate_project_layout(directory)
    return [
        "docker", "compose", "--env-file", PROJECT_ENV,
        "--project-name", f"pm-{slug}", "-f", PROJECT_COMPOSE,
    ]


def is_placeholder_env_value(value: str) -> bool:
    normalized = value.strip().strip('"\'').upper()
    return (
        normalized in PLACEHOLDER_VALUES
        or normalized.startswith("YOUR_")
        or normalized.startswith("<")
    )


def required_environment_missing(path: Path) -> list[str]:
    spec = read_project_manifest(path)
    values = parse_env_file(path / PROJECT_ENV)
    return [key for key in spec.get("required_env", []) if is_placeholder_env_value(values.get(key, ""))]


def is_secret_env_key(key: str) -> bool:
    upper = key.upper()
    return any(marker in upper for marker in ("TOKEN", "SECRET", "PASSWORD", "PASSWD", "API_KEY", "PRIVATE_KEY", "CREDENTIAL", "DATABASE_URL", "DSN", "_URL", "_URI", "COOKIE"))


def write_environment_file(path: Path, values: dict[str, str]) -> None:
    lines = ["# Private runtime variables managed by Ubuntu Project Manager. Do not commit this file."]
    for key in sorted(values):
        value = values[key]
        if not ENV_KEY_RE.fullmatch(key) or key.startswith(RESERVED_ENV_PREFIXES):
            raise ValueError(f"Недопустимое имя переменной: {key}")
        if not isinstance(value, str) or "\n" in value or "\r" in value or "\x00" in value:
            raise ValueError(f"Значение {key} должно быть одной строкой")
        # Single-quoted Compose dotenv values are literal (no $ interpolation).
        escaped = value.replace("\\", "\\\\").replace("'", "\\'")
        lines.append(f"{key}='{escaped}'")
    target = path / PROJECT_ENV
    temp = path / f"{PROJECT_ENV}.tmp"
    temp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    temp.chmod(0o600)
    os.replace(temp, target)

def run_command(command: list[str], cwd: Path, timeout: int = 60) -> tuple[int, str]:
    try:
        result = subprocess.run(
            command,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            errors="replace",
            timeout=timeout,
            check=False,
            env={**os.environ, "COMPOSE_ANSI": "never", "DOCKER_CLI_HINTS": "false"},
        )
        return result.returncode, (result.stdout or "")[-30000:]
    except subprocess.TimeoutExpired as exc:
        output = exc.stdout or ""
        if isinstance(output, bytes):
            output = output.decode("utf-8", "replace")
        return 124, (str(output) + "\nКоманда превысила лимит времени.")[-30000:]
    except FileNotFoundError:
        return 127, "Не найдена команда docker. Установите Docker Engine и плагин Docker Compose v2."
    except OSError as exc:
        return 1, f"Не удалось выполнить команду: {exc}"


def read_file_tail(path: Path, max_bytes: int = 30000) -> str:
    try:
        with path.open("rb") as stream:
            stream.seek(0, os.SEEK_END)
            size = stream.tell()
            stream.seek(max(0, size - max_bytes))
            data = stream.read()
        text = data.decode("utf-8", "replace")
        if size > max_bytes:
            text = f"[Показан конец файла; полный отчёт: {path.name}]\n" + text
        return text
    except OSError as exc:
        return f"Не удалось прочитать лог: {exc}"


def new_diagnostic_file(slug: str, label: str = "run", job_id: str | None = None) -> Path:
    if not slug or safe_slug(slug) != slug:
        raise ValueError("Некорректное имя проекта для диагностического отчёта")
    directory = DIAGNOSTICS_DIR / slug
    directory.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    suffix = job_id or uuid.uuid4().hex[:8]
    path = directory / f"{stamp}_{label}_{suffix}.log"
    path.write_text(
        "Ubuntu Project Manager — диагностический отчёт\n"
        f"Проект: {slug}\nВремя UTC: {utc_now()}\n\n",
        encoding="utf-8",
    )
    return path


def append_log_section(log_path: Path, title: str, content: str = "") -> None:
    with log_path.open("a", encoding="utf-8", errors="replace") as stream:
        stream.write(f"\n{'=' * 24} {title} {'=' * 24}\n")
        if content:
            stream.write(content)
            if not content.endswith("\n"):
                stream.write("\n")


def run_command_to_log(
    command: list[str],
    cwd: Path,
    log_path: Path,
    timeout: int = 300,
) -> int:
    """Run a command with combined stdout/stderr streamed to a persistent full log."""
    with log_path.open("a", encoding="utf-8", errors="replace") as stream:
        stream.write(f"\n$ (cwd={cwd}) {shlex.join(command)}\n")
        stream.flush()
        try:
            process = subprocess.Popen(
                command,
                cwd=str(cwd),
                stdout=stream,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                text=True,
                env={**os.environ, "COMPOSE_ANSI": "never", "DOCKER_CLI_HINTS": "false"},
                close_fds=True,
            )
            try:
                code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                stream.write(f"\nКоманда превысила лимит времени ({timeout} сек.).\n")
                stream.flush()
                return 124
            stream.write(f"\n[Код завершения: {code}]\n")
            stream.flush()
            return int(code)
        except FileNotFoundError:
            stream.write("Не найдена команда docker. Установите Docker Engine и Docker Compose v2.\n")
            return 127
        except OSError as exc:
            stream.write(f"Не удалось выполнить команду: {exc}\n")
            return 1


def parse_compose_ps(output: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(row, dict):
            continue
        rows.append({
            "id": str(row.get("ID") or row.get("Id") or row.get("id") or ""),
            "name": str(row.get("Name") or row.get("name") or ""),
            "service": str(row.get("Service") or row.get("service") or ""),
            "state": str(row.get("State") or row.get("state") or "unknown"),
            "status": str(row.get("Status") or row.get("status") or ""),
            "health": str(row.get("Health") or row.get("health") or ""),
            "exit_code": str(row.get("ExitCode") or row.get("exit_code") or ""),
        })
    return rows


def project_status(slug: str, path: Path) -> dict[str, Any]:
    command = compose_base(slug, path) + ["ps", "--all", "--format", "json"]
    code, output = run_command(command, path, timeout=15)
    if code != 0:
        return {"state": "unknown", "services": [], "status_error": output[-1200:]}
    services = parse_compose_ps(output)
    if not services:
        state = "stopped"
    else:
        states = [item["state"].lower() for item in services]
        if all(item == "running" for item in states) and not any(item.get("health", "").lower() == "unhealthy" for item in services):
            state = "running"
        elif all(item in {"exited", "stopped", "created", "dead"} for item in states):
            state = "stopped"
        else:
            state = "partial"
    return {"state": state, "services": services}


def collect_project_diagnostics(slug: str, path: Path, log_path: Path) -> dict[str, Any]:
    """Append complete Compose status, all retained container logs and inspect state."""
    base = compose_base(slug, path)
    append_log_section(log_path, "Версии и состояние Docker Engine")
    for title, command in (
        ("Docker version", ["docker", "version"]),
        ("Docker Compose version", ["docker", "compose", "version"]),
        ("Docker storage usage", ["docker", "system", "df"]),
    ):
        append_log_section(log_path, title)
        run_command_to_log(command, path, log_path, timeout=30)

    append_log_section(log_path, "Состояние Docker / Compose")
    ps_command = base + ["ps", "--all", "--format", "json"]
    ps_code, ps_output = run_command(ps_command, path, timeout=30)
    append_log_section(log_path, f"COMPOSE PS (exit={ps_code})", ps_output or "(пустой вывод)")
    services = parse_compose_ps(ps_output)

    states = [item["state"].lower() for item in services]
    if services and all(state == "running" for state in states) and not any(item.get("health", "").lower() == "unhealthy" for item in services):
        state = "running"
    elif services and all(state in {"exited", "stopped", "created", "dead"} for state in states):
        state = "stopped"
    elif services:
        state = "partial"
    else:
        state = "stopped"

    append_log_section(log_path, "Полные логи контейнеров (все доступные Docker log entries)")
    logs_code = run_command_to_log(
        base + ["logs", "--no-color", "--timestamps"],
        path,
        log_path,
        timeout=180,
    )
    append_log_section(log_path, f"Код завершения docker compose logs: {logs_code}")

    container_ids = [item["id"] for item in services if item.get("id")]
    if container_ids:
        append_log_section(log_path, "Подробное состояние контейнеров (docker inspect)")
        inspect_code = run_command_to_log(
            ["docker", "inspect", "--format", "{{json .State}}", *container_ids],
            path,
            log_path,
            timeout=30,
        )
        append_log_section(log_path, f"Код завершения docker inspect: {inspect_code}")
    else:
        append_log_section(log_path, "Docker inspect", "Контейнеры не созданы или Docker Compose не вернул ID.")

    append_log_section(log_path, "Сводка сервисов", json.dumps(services, ensure_ascii=False, indent=2))
    append_log_section(log_path, "Итог", f"Состояние проекта: {state}; сервисов найдено: {len(services)}")
    prune_diagnostics(slug)
    return {"state": state, "services": services, "logs_exit_code": logs_code}


def prune_diagnostics(slug: str) -> None:
    directory = DIAGNOSTICS_DIR / slug
    try:
        files = sorted(directory.glob("*.log"), key=lambda item: item.stat().st_mtime, reverse=True)
        for old in files[DIAGNOSTICS_KEEP_PER_PROJECT:]:
            old.unlink(missing_ok=True)
    except OSError:
        pass


def latest_diagnostic_path(slug: str) -> Path | None:
    if not slug or safe_slug(slug) != slug:
        raise HTTPException(status_code=400, detail="Некорректное имя проекта")
    directory = DIAGNOSTICS_DIR / slug
    if not directory.is_dir():
        return None
    files = sorted(directory.glob("*.log"), key=lambda item: item.stat().st_mtime, reverse=True)
    return files[0] if files else None


def latest_operation_diagnostic_path(slug: str) -> Path | None:
    directory = DIAGNOSTICS_DIR / slug
    if not directory.is_dir():
        return None
    candidates = [
        file for file in directory.glob("*.log")
        if "_start_" in file.name or "_restart_" in file.name or "_upload-validation_" in file.name
    ]
    return max(candidates, key=lambda item: item.stat().st_mtime) if candidates else None


def create_live_diagnostic(slug: str, path: Path) -> Path:
    previous_operation = latest_operation_diagnostic_path(slug)
    log_path = new_diagnostic_file(slug, "manual")
    if previous_operation and previous_operation != log_path:
        append_log_section(
            log_path,
            f"Последний полный отчёт сборки/запуска: {previous_operation.name}",
            previous_operation.read_text("utf-8", errors="replace"),
        )
    collect_project_diagnostics(slug, path, log_path)
    return log_path


def create_csrf(request: Request) -> str:
    token = request.session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        request.session["csrf_token"] = token
    return str(token)


def require_auth(request: Request) -> None:
    if request.session.get("authenticated") is not True:
        raise HTTPException(status_code=401, detail="Требуется вход")


def require_csrf(request: Request, submitted: str | None = None) -> None:
    expected = str(request.session.get("csrf_token", ""))
    candidate = submitted or request.headers.get("x-csrf-token", "")
    if not expected or not candidate or not hmac.compare_digest(expected, candidate):
        raise HTTPException(status_code=403, detail="Проверка безопасности запроса не пройдена. Обновите страницу.")


def secure_extract_zip(archive_path: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=False)
    total_size = 0
    with zipfile.ZipFile(archive_path) as archive:
        infos = archive.infolist()
        if not infos:
            raise ValueError("ZIP-архив пуст")
        if len(infos) > MAX_ARCHIVE_FILES:
            raise ValueError(f"В архиве слишком много файлов (максимум {MAX_ARCHIVE_FILES})")

        checked: list[tuple[zipfile.ZipInfo, Path]] = []
        seen: set[str] = set()
        for info in infos:
            raw_name = info.filename
            if "\\" in raw_name or "\x00" in raw_name:
                raise ValueError("В архиве найден небезопасный путь")
            pure = PurePosixPath(raw_name)
            if pure.is_absolute() or not pure.parts or any(part in ("..", "") for part in pure.parts):
                raise ValueError("В архиве найден путь за пределами папки проекта")
            if pure.parts[0].endswith(":"):
                raise ValueError("Абсолютные пути в ZIP запрещены")
            normalized = pure.as_posix().rstrip("/")
            if normalized in seen:
                raise ValueError("В архиве есть повторяющиеся пути")
            seen.add(normalized)

            unix_mode = (info.external_attr >> 16) & 0xFFFF
            file_type = unix_mode & 0o170000
            if file_type not in (0, 0o040000, 0o100000):
                raise ValueError("Символические ссылки и специальные файлы в ZIP запрещены")
            if info.file_size < 0 or info.file_size > MAX_EXTRACTED_BYTES:
                raise ValueError("Файл в архиве превышает допустимый размер")
            total_size += info.file_size
            if total_size > MAX_EXTRACTED_BYTES:
                raise ValueError("Распакованный архив превышает допустимый общий размер")
            target = destination.joinpath(*pure.parts)
            resolved = target.resolve()
            if destination.resolve() not in resolved.parents and resolved != destination.resolve():
                raise ValueError("Небезопасный путь в ZIP")
            checked.append((info, target))

        for info, target in checked:
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as source, target.open("xb") as output:
                shutil.copyfileobj(source, output, length=1024 * 1024)
            # Preserve executable bits (for entrypoint scripts) while stripping
            # setuid/setgid/sticky bits from archive metadata.
            unix_mode = (info.external_attr >> 16) & 0xFFFF
            permissions = unix_mode & 0o777
            if permissions == 0:
                permissions = 0o644
            permissions |= 0o600
            target.chmod(permissions)


def choose_project_root(extracted: Path) -> tuple[Path, str]:
    candidates = [extracted]
    children = [item for item in extracted.iterdir() if item.name not in {"__MACOSX", ".DS_Store"}]
    if len(children) == 1 and children[0].is_dir():
        candidates.append(children[0])
    for candidate in candidates:
        if (candidate / PROJECT_MANIFEST).is_file():
            validate_project_layout(candidate, create_env=True)
            return candidate, PROJECT_COMPOSE
    raise ValueError(
        f"Неверный формат проекта. В корне архива (или одной общей папке) обязательны "
        f"{PROJECT_MANIFEST}, {PROJECT_COMPOSE} и {PROJECT_ENV_EXAMPLE}. "
        f"См. PROJECT_FORMAT.md в архиве менеджера."
    )


async def run_job(job_id: str, slug: str, action: str) -> None:
    job = JOBS[job_id]
    lock = PROJECT_LOCKS.setdefault(slug, asyncio.Lock())
    if lock.locked():
        job.update(status="failed", output="Для этого проекта уже выполняется другая операция.", finished_at=utc_now())
        return
    async with lock:
        job.update(status="running", started_at=utc_now())
        log_path: Path | None = None
        try:
            path = project_path(slug)
            if action in {"start", "restart"}:
                # Create the report before preflight validation so malformed project
                # files and missing env files also produce an actionable diagnostic.
                log_path = new_diagnostic_file(slug, action, job_id)
                append_log_section(log_path, "Предварительная проверка проекта", f"Проверяем формат Project Manager v1 и {PROJECT_ENV}.")
            base = compose_base(slug, path)
            if action in {"start", "restart"}:
                missing = required_environment_missing(path)
                if missing:
                    append_log_section(
                        log_path,
                        "Проверка конфигурации: не заполнены обязательные переменные",
                        "Заполни переменные в разделе «Переменные» перед запуском: " + ", ".join(missing),
                    )
                    job.update(
                        status="failed",
                        output="Не заполнены обязательные переменные: " + ", ".join(missing) + ". Открой настройки .pm.env.",
                        finished_at=utc_now(),
                        diagnostic_file=str(log_path),
                        diagnostic_size=log_path.stat().st_size,
                    )
                    return
            if action == "start":
                command, timeout = base + ["up", "-d", "--build", "--remove-orphans"], 1800
            elif action == "stop":
                command, timeout = base + ["stop"], 300
            elif action == "restart":
                # `compose restart` does not apply changed env vars; recreate instead.
                command, timeout = base + ["up", "-d", "--build", "--force-recreate", "--remove-orphans"], 1800
            elif action == "delete":
                command, timeout = base + ["down"], 300
            else:
                raise RuntimeError("Неизвестная операция")

            if action in {"start", "restart"}:
                assert log_path is not None
                append_log_section(log_path, "Команда запуска", f"Действие: {action}\nКоманда: {shlex.join(command)}\n")
                code = await asyncio.to_thread(run_command_to_log, command, path, log_path, timeout)
                if code == 0:
                    await asyncio.sleep(max(0, STARTUP_VERIFY_DELAY_SECONDS))
                diagnostic = await asyncio.to_thread(collect_project_diagnostics, slug, path, log_path)
                if code == 0 and (diagnostic["state"] != "running" or not diagnostic["services"]):
                    code = 2
                    append_log_section(
                        log_path,
                        "Проверка после запуска: ОШИБКА",
                        "Команда Docker Compose завершилась успешно, но один или несколько сервисов не находятся в состоянии running.\n",
                    )
                elif code == 0:
                    append_log_section(log_path, "Проверка после запуска: УСПЕХ", "Все обнаруженные сервисы находятся в состоянии running.\n")
                output = read_file_tail(log_path, 30000)
                if code == 0:
                    job.update(status="succeeded", output="Проект запущен. Все сервисы работают.", finished_at=utc_now())
                else:
                    job.update(
                        status="failed",
                        output=f"Запуск не удался (код {code}). Полный диагностический отчёт приложен.",
                        finished_at=utc_now(),
                    )
                job["diagnostic_file"] = str(log_path)
                job["diagnostic_size"] = log_path.stat().st_size if log_path.exists() else 0
            else:
                code, output = await asyncio.to_thread(run_command, command, path, timeout)
                if code == 0 and action == "delete":
                    shutil.rmtree(path)
                    output += "\nФайлы проекта удалены. Именованные Docker volumes сохранены, чтобы не потерять данные."
                if code == 0:
                    job.update(status="succeeded", output=output or "Готово.", finished_at=utc_now())
                else:
                    job.update(status="failed", output=output or f"Команда завершилась с кодом {code}.", finished_at=utc_now())
        except Exception as exc:
            if log_path:
                append_log_section(log_path, "ВНУТРЕННЯЯ ОШИБКА МЕНЕДЖЕРА", f"{type(exc).__name__}: {exc}")
                job["diagnostic_file"] = str(log_path)
            job.update(status="failed", output=f"{type(exc).__name__}: {exc}", finished_at=utc_now())


async def schedule_job(slug: str, action: str) -> dict[str, str]:
    job_id = uuid.uuid4().hex[:16]
    JOBS[job_id] = {
        "id": job_id,
        "project": slug,
        "action": action,
        "status": "queued",
        "output": "Операция добавлена в очередь.",
        "created_at": utc_now(),
    }
    asyncio.create_task(run_job(job_id, slug, action))
    return {"job_id": job_id}


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/project-format")
async def project_format_document(request: Request):
    require_auth(request)
    document = APP_DIR.parent / "PROJECT_FORMAT.md"
    if not document.is_file():
        raise HTTPException(status_code=404, detail="Инструкция не найдена в сборке менеджера")
    return FileResponse(document, media_type="text/markdown; charset=utf-8", filename="PROJECT_FORMAT.md")


@app.get("/project-template.zip")
async def project_template_archive(request: Request):
    require_auth(request)
    template = APP_DIR.parent / "project-template.zip"
    if not template.is_file():
        raise HTTPException(status_code=404, detail="Шаблон проекта не найден в сборке менеджера")
    return FileResponse(template, media_type="application/zip", filename="project-manager-python-template.zip")


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request) -> HTMLResponse:
    token = create_csrf(request)
    html = (TEMPLATE_DIR / "login.html").read_text("utf-8").replace("__CSRF__", token)
    return HTMLResponse(html)


@app.post("/login")
async def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    csrf_token: str = Form(...),
) -> RedirectResponse:
    require_csrf(request, csrf_token)
    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    recent = [stamp for stamp in LOGIN_FAILURES.get(client_ip, []) if now - stamp < 600]
    LOGIN_FAILURES[client_ip] = recent
    if len(recent) >= 5:
        raise HTTPException(status_code=429, detail="Слишком много неудачных попыток. Попробуй через 10 минут.")
    if not (hmac.compare_digest(username, ADMIN_USERNAME) and hmac.compare_digest(password, ADMIN_PASSWORD)):
        LOGIN_FAILURES[client_ip].append(now)
        raise HTTPException(status_code=401, detail="Неверный логин или пароль")
    LOGIN_FAILURES.pop(client_ip, None)
    request.session.clear()
    request.session["authenticated"] = True
    request.session["csrf_token"] = secrets.token_urlsafe(32)
    return RedirectResponse("/", status_code=303)


@app.post("/logout")
async def logout(request: Request, csrf_token: str = Form(...)) -> RedirectResponse:
    require_auth(request)
    require_csrf(request, csrf_token)
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request) -> HTMLResponse:
    if request.session.get("authenticated") is not True:
        return RedirectResponse("/login", status_code=303)
    csrf = create_csrf(request)
    html = (TEMPLATE_DIR / "dashboard.html").read_text("utf-8").replace("__CSRF__", csrf)
    return HTMLResponse(html)


@app.get("/api/projects")
async def list_projects(request: Request) -> JSONResponse:
    require_auth(request)
    projects: list[dict[str, Any]] = []
    for path in sorted(PROJECTS_DIR.iterdir(), key=lambda p: p.name.lower()):
        if not path.is_dir() or path.name.startswith("."):
            continue
        compose = find_compose_file(path)
        if not compose:
            continue
        metadata = read_metadata(path)
        try:
            await asyncio.to_thread(validate_project_layout, path)
            status = await asyncio.to_thread(project_status, path.name, path)
            status["missing_required"] = await asyncio.to_thread(required_environment_missing, path)
        except (ValueError, OSError) as exc:
            status = {"state": "invalid", "services": [], "status_error": str(exc)}
        projects.append({
            "slug": path.name,
            "name": str(metadata.get("name") or path.name),
            "created_at": str(metadata.get("created_at") or ""),
            "compose_file": compose,
            "format_version": metadata.get("format_version", 1),
            "app_service": metadata.get("app_service", "app"),
            **status,
        })
    return JSONResponse({"projects": projects})


@app.post("/api/projects")
async def upload_project(
    request: Request,
    name: str = Form(...),
    file: UploadFile = File(...),
) -> JSONResponse:
    require_auth(request)
    require_csrf(request)
    if not file.filename or not file.filename.lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="Загрузи проект в формате .zip")
    display_name = name.strip() or Path(file.filename).stem
    slug = safe_slug(display_name)
    if not slug:
        raise HTTPException(status_code=400, detail="Укажи корректное название проекта")
    final_path = PROJECTS_DIR / slug
    if final_path.exists():
        raise HTTPException(status_code=409, detail="Проект с таким названием уже существует")

    temp_dir = PROJECTS_DIR / f".upload-{uuid.uuid4().hex}"
    archive_path = temp_dir / "upload.zip"
    extraction_path = temp_dir / "extracted"
    project_stage = temp_dir / "project"
    temp_dir.mkdir(mode=0o700)
    size = 0
    try:
        with archive_path.open("xb") as output:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_BYTES:
                    raise HTTPException(status_code=413, detail=f"ZIP-файл больше лимита {MAX_UPLOAD_BYTES // (1024 * 1024)} МБ")
                output.write(chunk)
        if size == 0:
            raise HTTPException(status_code=400, detail="Загружен пустой файл")
        try:
            await asyncio.to_thread(secure_extract_zip, archive_path, extraction_path)
            source_root, compose_file = choose_project_root(extraction_path)
            shutil.move(str(source_root), str(project_stage))
            spec = validate_project_layout(project_stage)
            validation_log = new_diagnostic_file(slug, "upload-validation")
            config_command = ["docker", "compose", "--env-file", PROJECT_ENV, "--project-name", f"pm-{slug}", "-f", PROJECT_COMPOSE, "config", "--quiet"]
            append_log_section(validation_log, "Проверка строгого формата проекта v1", f"Manifest: {PROJECT_MANIFEST}\nCompose: {PROJECT_COMPOSE}\nEnvironment template: {PROJECT_ENV_EXAMPLE}\nRuntime environment: {PROJECT_ENV}\nApp service: {spec['app_service']}\n")
            append_log_section(validation_log, "Проверка конфигурации Docker Compose (значения секретов не выводятся)")
            config_code = await asyncio.to_thread(run_command_to_log, config_command, project_stage, validation_log, 60)
            prune_diagnostics(slug)
            if config_code != 0:
                raise ValueError(
                    "Docker Compose не принял конфигурацию. Полный вывод проверки сохранён в диагностике "
                    f"{validation_log.name}. Скачать отчёт: /api/diagnostics/{slug}/latest. "
                    f"Последние строки:\n{read_file_tail(validation_log, 5000)}"
                )
            metadata = {
                "name": spec.get("name") or display_name[:80],
                "slug": slug,
                "compose_file": PROJECT_COMPOSE,
                "env_file": PROJECT_ENV,
                "format_version": 1,
                "app_service": spec["app_service"],
                "required_env": spec.get("required_env", []),
                "created_at": utc_now(),
            }
            (project_stage / ".project-manager.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), "utf-8")
            os.replace(project_stage, final_path)
        except (zipfile.BadZipFile, OSError, ValueError, RuntimeError) as exc:
            raise HTTPException(status_code=400, detail=f"Не удалось добавить проект: {exc}") from exc
    finally:
        try:
            await file.close()
        except Exception:
            pass
        shutil.rmtree(temp_dir, ignore_errors=True)

    return JSONResponse({"ok": True, "slug": slug, "name": display_name}, status_code=201)


@app.get("/api/projects/{slug}/environment")
async def get_project_environment(slug: str, request: Request) -> JSONResponse:
    require_auth(request)
    path = project_path(slug)
    spec = validate_project_layout(path)
    values = parse_env_file(path / PROJECT_ENV)
    required = set(spec.get("required_env", []))
    variables = []
    for key in sorted(values):
        secret = is_secret_env_key(key)
        value = values[key]
        variables.append({
            "key": key,
            "value": "" if secret else value,
            "secret": secret,
            "configured": bool(value) and not is_placeholder_env_value(value),
            "required": key in required,
        })
    return JSONResponse({
        "project": slug,
        "env_file": PROJECT_ENV,
        "variables": variables,
        "required_env": sorted(required),
        "missing_required": required_environment_missing(path),
    })


@app.put("/api/projects/{slug}/environment")
async def update_project_environment(slug: str, request: Request) -> JSONResponse:
    require_auth(request)
    require_csrf(request)
    path = project_path(slug)
    spec = validate_project_layout(path)
    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Тело запроса должно быть JSON") from exc
    submitted = payload.get("variables") if isinstance(payload, dict) else None
    if not isinstance(submitted, list) or len(submitted) > 200:
        raise HTTPException(status_code=400, detail="variables должен быть списком максимум из 200 переменных")
    current = parse_env_file(path / PROJECT_ENV)
    updated: dict[str, str] = {}
    for item in submitted:
        if not isinstance(item, dict):
            raise HTTPException(status_code=400, detail="Каждая переменная должна быть объектом key/value")
        key = item.get("key")
        value = item.get("value", "")
        if not isinstance(key, str) or not ENV_KEY_RE.fullmatch(key) or key.startswith(RESERVED_ENV_PREFIXES):
            raise HTTPException(status_code=400, detail=f"Недопустимое имя переменной: {key}")
        if key in updated:
            raise HTTPException(status_code=400, detail=f"Переменная {key} указана повторно")
        if item.get("keep_existing") is True and value == "" and key in current:
            value = current[key]
        if not isinstance(value, str) or len(value) > 8192 or "\n" in value or "\r" in value or "\x00" in value:
            raise HTTPException(status_code=400, detail=f"Значение {key} должно быть одной строкой до 8192 символов")
        updated[key] = value
    missing_keys = sorted(set(spec.get("required_env", [])) - set(updated))
    if missing_keys:
        raise HTTPException(status_code=400, detail="Нельзя удалить обязательные переменные: " + ", ".join(missing_keys))
    write_environment_file(path, updated)
    missing_values = required_environment_missing(path)
    return JSONResponse({
        "ok": True,
        "env_file": PROJECT_ENV,
        "saved": len(updated),
        "missing_required": missing_values,
        "message": "Переменные сохранены. Для применения изменений пересоздай контейнеры кнопкой «Сохранить и запустить»." if not missing_values else "Переменные сохранены, но обязательные значения ещё не заполнены.",
    })


@app.post("/api/projects/{slug}/actions/{action}")
async def project_action(slug: str, action: str, request: Request) -> JSONResponse:
    require_auth(request)
    require_csrf(request)
    if action not in {"start", "stop", "restart", "delete"}:
        raise HTTPException(status_code=404, detail="Неизвестная операция")
    project_path(slug)
    job = await schedule_job(slug, action)
    return JSONResponse(job, status_code=202)


@app.get("/api/jobs/{job_id}")
async def job_status(job_id: str, request: Request) -> JSONResponse:
    require_auth(request)
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Задача не найдена (возможно, панель перезапускалась)")
    return JSONResponse(job)


@app.get("/api/projects/{slug}/logs")
async def project_logs(slug: str, request: Request, tail: int = 200) -> JSONResponse:
    require_auth(request)
    path = project_path(slug)
    tail = max(1, min(tail, 1000))
    command = compose_base(slug, path) + ["logs", "--tail", str(tail), "--no-color", "--timestamps"]
    code, output = await asyncio.to_thread(run_command, command, path, 30)
    if code != 0 and not output:
        output = "Логи недоступны. Возможно, контейнеры ещё не запускались."
    return JSONResponse({"logs": output, "exit_code": code})


@app.get("/api/projects/{slug}/diagnostics")
async def project_diagnostics(slug: str, request: Request) -> JSONResponse:
    require_auth(request)
    path = project_path(slug)
    log_path = await asyncio.to_thread(create_live_diagnostic, slug, path)
    # UI preview is deliberately bounded; the complete report remains downloadable.
    return JSONResponse({
        "filename": log_path.name,
        "size": log_path.stat().st_size,
        "preview": read_file_tail(log_path, 200000),
        "download_url": f"/api/projects/{slug}/diagnostics/download",
    })


@app.get("/api/projects/{slug}/diagnostics/download")
async def download_project_diagnostics(slug: str, request: Request):
    require_auth(request)
    project_path(slug)
    log_path = latest_diagnostic_path(slug)
    if log_path is None:
        log_path = await asyncio.to_thread(create_live_diagnostic, slug, project_path(slug))
    return FileResponse(log_path, media_type="text/plain; charset=utf-8", filename=log_path.name)


@app.get("/api/diagnostics/{slug}/latest")
async def download_latest_diagnostic(slug: str, request: Request):
    require_auth(request)
    log_path = latest_diagnostic_path(slug)
    if log_path is None:
        raise HTTPException(status_code=404, detail="Диагностический отчёт не найден")
    return FileResponse(log_path, media_type="text/plain; charset=utf-8", filename=log_path.name)


@app.exception_handler(HTTPException)
async def http_error_handler(request: Request, exc: HTTPException):
    if request.url.path.startswith("/api/"):
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
    if exc.status_code == 401:
        return RedirectResponse("/login", status_code=303)
    return HTMLResponse(str(exc.detail), status_code=exc.status_code)
