from __future__ import annotations

import asyncio
import gzip
import json
import os
import shutil
import tempfile
import uuid
from pathlib import Path

try:
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
    from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters
except ImportError:  # Optional in test/dev environments until the requirements are installed.
    InlineKeyboardButton = InlineKeyboardMarkup = Update = None
    Application = CallbackQueryHandler = CommandHandler = ContextTypes = MessageHandler = filters = None

from app import main as manager

BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
ADMIN_IDS = {int(x.strip()) for x in os.environ.get("ADMIN_TELEGRAM_IDS", "").split(",") if x.strip().isdigit()}


def is_admin(update: Update) -> bool:
    user = update.effective_user
    return bool(user and user.id in ADMIN_IDS)


async def deny(update: Update) -> None:
    if update.effective_message:
        await update.effective_message.reply_text("⛔ Доступ только для администратора сервера.")


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update):
        return await deny(update)
    await update.effective_message.reply_text(
        "🖥 Project Manager\n\n"
        "Отправь ZIP-архив в строгом формате Project Manager v1 — я загружу и проверю его.\n\n"
        "/projects — список проектов\n"
        "/help — помощь\n\n"
        "Управление контейнерами доступно кнопками под каждым проектом."
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update):
        return await deny(update)
    await update.effective_message.reply_text(
        "Стандарт проекта Project Manager v1:\n"
        "1. В корне архива должны быть pm-project.json, compose.yaml и .pm.env.example.\n"
        "2. В pm-project.json указывается app_service и required_env.\n"
        "3. В compose.yaml сервис приложения должен подключать .pm.env через env_file.\n"
        "4. Не добавляй .pm.env в ZIP: менеджер создаёт приватный .pm.env сам. Заполни его в веб-панели → Переменные.\n"
        "5. Отправь ZIP этому боту как документ.\n\n"
        "Кнопки проекта позволяют запустить, остановить, перезапустить, получить полный диагностический отчёт или удалить проект.\n"
        "Если запуск не удастся, я автоматически пришлю файл с выводом сборки, состоянием контейнеров, полными доступными логами и docker inspect.\n"
        "Внимание: загружаемый Compose-файл выполняется с правами Docker-хоста. Загружай только свой доверенный код."
    )


def project_keyboard(slug: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("▶ Запустить", callback_data=f"start:{slug}"), InlineKeyboardButton("⏹ Остановить", callback_data=f"stop:{slug}")],
        [InlineKeyboardButton("🔄 Перезапустить", callback_data=f"restart:{slug}"), InlineKeyboardButton("🧾 Полный отчёт", callback_data=f"logs:{slug}")],
        [InlineKeyboardButton("🗑 Удалить", callback_data=f"confirm_delete:{slug}")],
    ])


async def projects(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update):
        return await deny(update)
    paths = [p for p in sorted(manager.PROJECTS_DIR.iterdir()) if p.is_dir() and not p.name.startswith(".") and manager.find_compose_file(p)]
    if not paths:
        await update.effective_message.reply_text("Пока нет загруженных проектов. Отправь ZIP-архив с Docker Compose.")
        return
    for path in paths:
        try:
            await asyncio.to_thread(manager.validate_project_layout, path)
            status = await asyncio.to_thread(manager.project_status, path.name, path)
            icon = {"running": "🟢", "stopped": "⚪", "partial": "🟡"}.get(status["state"], "❔")
            await update.effective_message.reply_text(
                f"{icon} {manager.read_metadata(path).get('name', path.name)}\n"
                f"Папка: {path.name}\nСтатус: {status['state']}",
                reply_markup=project_keyboard(path.name),
            )
        except (ValueError, OSError) as exc:
            await update.effective_message.reply_text(
                f"⚠️ {path.name}: проект не соответствует Project Format v1.\n{str(exc)[:1200]}"
            )


async def upload_project(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update):
        return await deny(update)
    doc = update.effective_message.document
    if not doc or not doc.file_name or not doc.file_name.lower().endswith(".zip"):
        await update.effective_message.reply_text("Пришли проект ZIP-архивом как документ.")
        return
    # Telegram's hosted Bot API currently limits getFile downloads to 20 MB.
    if doc.file_size and doc.file_size > 20 * 1024 * 1024:
        await update.effective_message.reply_text("Архив больше 20 МБ. Для больших проектов используй веб-панель загрузки.")
        return
    status = await update.effective_message.reply_text("📦 Получаю архив и проверяю Docker Compose…")
    diagnostic_path: Path | None = None
    temp = Path(tempfile.mkdtemp(prefix="pm-tg-upload-", dir=manager.PROJECTS_DIR))
    try:
        archive_path = temp / "upload.zip"
        tg_file = await context.bot.get_file(doc.file_id)
        await tg_file.download_to_drive(custom_path=archive_path)
        display_name = Path(doc.file_name).stem[:80]
        slug = manager.safe_slug(display_name)
        if not slug:
            raise ValueError("Не удалось определить имя проекта из названия архива")
        final_path = manager.PROJECTS_DIR / slug
        if final_path.exists():
            raise ValueError(f"Проект {slug} уже существует. Удали его или переименуй архив.")
        extracted = temp / "extracted"
        await asyncio.to_thread(manager.secure_extract_zip, archive_path, extracted)
        source_root, compose_file = manager.choose_project_root(extracted)
        stage = temp / "project"
        shutil.move(str(source_root), str(stage))
        spec = manager.validate_project_layout(stage)
        command = ["docker", "compose", "--env-file", manager.PROJECT_ENV, "--project-name", f"pm-{slug}", "-f", manager.PROJECT_COMPOSE, "config", "--quiet"]
        diagnostic_path = manager.new_diagnostic_file(slug, "upload-validation")
        manager.append_log_section(diagnostic_path, "Проверка строгого формата проекта v1", f"Manifest: {manager.PROJECT_MANIFEST}\nCompose: {manager.PROJECT_COMPOSE}\nEnv template: {manager.PROJECT_ENV_EXAMPLE}\nApp service: {spec['app_service']}\n")
        manager.append_log_section(diagnostic_path, "Проверка Docker Compose; значения переменных в отчёт не добавляются")
        code = await asyncio.to_thread(manager.run_command_to_log, command, stage, diagnostic_path, 60)
        manager.prune_diagnostics(slug)
        if code:
            raise ValueError(
                "Docker Compose не прошёл проверку. Полный вывод будет приложен отдельным файлом. "
                + manager.read_file_tail(diagnostic_path, 2500)
            )
        metadata = {
            "name": spec.get("name") or display_name,
            "slug": slug,
            "compose_file": manager.PROJECT_COMPOSE,
            "env_file": manager.PROJECT_ENV,
            "format_version": 1,
            "app_service": spec["app_service"],
            "required_env": spec.get("required_env", []),
            "created_at": manager.utc_now(),
        }
        (stage / ".project-manager.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), "utf-8")
        os_replace = __import__("os").replace
        os_replace(stage, final_path)
        await status.edit_text(
            f"✅ Проект «{display_name}» загружен и проверен.\n"
            f"Следующий шаг: открой веб-панель → Переменные и заполни {manager.PROJECT_ENV}.\n"
            "После этого нажми «Запустить».",
            reply_markup=project_keyboard(slug),
        )
    except Exception as exc:
        await status.edit_text(f"❌ Не удалось загрузить проект: {str(exc)[:2500]}")
        if diagnostic_path and diagnostic_path.is_file():
            await send_diagnostic_document(
                context.bot,
                update.effective_chat.id,
                diagnostic_path,
                "Полный отчёт проверки Docker Compose при загрузке проекта.",
            )
    finally:
        shutil.rmtree(temp, ignore_errors=True)


async def send_diagnostic_document(bot, chat_id: int, log_path: Path, caption: str) -> None:
    """Send full logs; compress if needed to fit Telegram's hosted Bot API limit."""
    if not log_path.is_file():
        await bot.send_message(chat_id=chat_id, text="Диагностический файл не найден на диске сервера.")
        return
    send_path = log_path
    temporary_paths: list[Path] = []
    try:
        if log_path.stat().st_size > 45 * 1024 * 1024:
            compressed_path = log_path.with_suffix(log_path.suffix + ".gz")
            temporary_paths.append(compressed_path)
            with log_path.open("rb") as source, gzip.open(compressed_path, "wb", compresslevel=6) as target:
                shutil.copyfileobj(source, target, length=1024 * 1024)
            send_path = compressed_path
        if send_path.stat().st_size > 49 * 1024 * 1024:
            # Keep the original full report on the server. Send a sizeable tail as
            # a fallback if even gzip compression exceeds Telegram's upload limit.
            temporary_path = log_path.with_suffix(log_path.suffix + ".tail.log")
            temporary_paths.append(temporary_path)
            max_bytes = 45 * 1024 * 1024
            with log_path.open("rb") as source:
                source.seek(max(0, log_path.stat().st_size - max_bytes))
                data = source.read(max_bytes)
            prefix = "[В Telegram отправлен конец отчёта из-за ограничения размера. Полный файл остаётся на сервере.]\n".encode("utf-8")
            temporary_path.write_bytes(prefix + data)
            send_path = temporary_path
            caption += "\n⚠️ Из-за лимита Telegram отправлена только заключительная часть; полный файл сохранён на сервере."
        with send_path.open("rb") as document:
            await bot.send_document(
                chat_id=chat_id,
                document=document,
                filename=send_path.name,
                caption=caption[:900],
            )
    finally:
        for temporary_path in temporary_paths:
            if temporary_path.exists():
                try:
                    temporary_path.unlink()
                except OSError:
                    pass


async def notify_job_completion(bot, chat_id: int, job_id: str, slug: str, action: str) -> None:
    """Wait independently of the callback request and notify after long builds finish."""
    for _ in range(3600):
        await asyncio.sleep(1)
        job = manager.JOBS.get(job_id, {})
        if job.get("status") in {"succeeded", "failed"}:
            succeeded = job["status"] == "succeeded"
            if succeeded:
                await bot.send_message(chat_id=chat_id, text=f"✅ Проект {slug}: операция «{action}» завершена успешно.")
            else:
                await bot.send_message(
                    chat_id=chat_id,
                    text=f"❌ Проект {slug}: {job.get('output', 'операция завершилась с ошибкой')}\n"
                         "Прикрепляю полный диагностический отчёт.",
                )
            diagnostic_file = job.get("diagnostic_file")
            if diagnostic_file and Path(diagnostic_file).is_file() and (not succeeded or action in {"start", "restart"}):
                await send_diagnostic_document(
                    bot,
                    chat_id,
                    Path(diagnostic_file),
                    f"Диагностика проекта {slug} · {action} · {job.get('status')}",
                )
            return
    await bot.send_message(chat_id=chat_id, text=f"⚠️ Операция проекта {slug} выполняется больше часа. Проверь сервер и его логи.")


async def callbacks(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not is_admin(update):
        await query.answer("Нет доступа", show_alert=True)
        return
    await query.answer()
    action, slug = query.data.split(":", 1)
    try:
        path = manager.project_path(slug)
        if action == "logs":
            await query.message.reply_text("🧾 Собираю полный диагностический отчёт: сборка, состояние сервисов, логи контейнеров и docker inspect…")
            log_path = await asyncio.to_thread(manager.create_live_diagnostic, slug, path)
            await send_diagnostic_document(
                context.bot,
                query.message.chat_id,
                log_path,
                f"Полная диагностика проекта {slug}. Отчёт также сохранён на сервере.",
            )
            return
        if action == "confirm_delete":
            keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("Да, удалить", callback_data=f"delete:{slug}"), InlineKeyboardButton("Отмена", callback_data=f"cancel:{slug}")]])
            await query.edit_message_reply_markup(reply_markup=keyboard)
            return
        if action == "cancel":
            await query.edit_message_reply_markup(reply_markup=project_keyboard(slug))
            return
        if action not in {"start", "stop", "restart", "delete"}:
            return
        job = await manager.schedule_job(slug, action)
        await query.message.reply_text(
            f"⏳ Операция «{action}» запущена. ID: {job['job_id']}\n"
            "Я пришлю результат отдельным сообщением, даже если сборка займёт несколько минут."
        )
        context.application.create_task(
            notify_job_completion(context.bot, query.message.chat_id, job["job_id"], slug, action),
            name=f"notify-{job['job_id']}",
        )
    except Exception as exc:
        await query.message.reply_text(f"❌ Ошибка: {str(exc)[:2500]}")


async def start_bot() -> Application | None:
    if not BOT_TOKEN:
        return None
    if Application is None:
        raise RuntimeError("Не установлена зависимость python-telegram-bot. Пересобери контейнер.")
    if not ADMIN_IDS:
        raise RuntimeError("TELEGRAM_BOT_TOKEN задан, но ADMIN_TELEGRAM_IDS пуст. Укажи свой Telegram user ID.")
    application = Application.builder().token(BOT_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("projects", projects))
    application.add_handler(CallbackQueryHandler(callbacks))
    application.add_handler(MessageHandler(filters.Document.ALL, upload_project))
    await application.initialize()
    await application.start()
    await application.updater.start_polling(drop_pending_updates=True)
    return application


async def stop_bot(application: Application | None) -> None:
    if application is None:
        return
    await application.updater.stop()
    await application.stop()
    await application.shutdown()
