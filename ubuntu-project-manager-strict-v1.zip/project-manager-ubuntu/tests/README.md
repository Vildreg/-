Run tests in an environment with Python, FastAPI, python-multipart, itsdangerous and pytest installed:

```bash
PROJECTS_DIR=/tmp/pm-test-projects DIAGNOSTICS_DIR=/tmp/pm-test-diagnostics ADMIN_USERNAME=admin ADMIN_PASSWORD=test SESSION_SECRET=12345678901234567890123456789012 pytest -q
```
