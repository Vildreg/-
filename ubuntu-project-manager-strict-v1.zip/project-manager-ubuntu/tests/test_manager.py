from __future__ import annotations

import json
import os
import stat
import sys
import zipfile
from pathlib import Path

import pytest

# The app module reads environment at import time; isolate project data for tests.
TEST_ROOT = Path(__file__).parent / ".testdata"
TEST_ROOT.mkdir(exist_ok=True)
os.environ.setdefault("PROJECTS_DIR", str(TEST_ROOT / "projects"))
os.environ.setdefault("ADMIN_USERNAME", "admin")
os.environ.setdefault("ADMIN_PASSWORD", "test-password-for-tests")
os.environ.setdefault("SESSION_SECRET", "test-session-secret-at-least-32-characters-long")

sys.path.insert(0, str(Path(__file__).parents[1]))
from app import main  # noqa: E402


def make_zip(path: Path, files: dict[str, str]) -> None:
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, content in files.items():
            zf.writestr(name, content)




def project_files(prefix: str = "") -> dict[str, str]:
    return {
        f"{prefix}pm-project.json": json.dumps({
            "format_version": 1,
            "name": "Test App",
            "description": "test",
            "compose_file": "compose.yaml",
            "env_file": ".pm.env",
            "env_example_file": ".pm.env.example",
            "app_service": "app",
            "required_env": ["BOT_TOKEN", "ADMIN_ID"],
        }),
        f"{prefix}compose.yaml": "services:\n  app:\n    image: python:3.12-slim\n    command: [\"python\", \"-c\", \"import time; time.sleep(3600)\"]\n    env_file:\n      - .pm.env\n",
        f"{prefix}.pm.env.example": "BOT_TOKEN=CHANGE_ME\nADMIN_ID=CHANGE_ME\nLOG_LEVEL=INFO\n",
        f"{prefix}main.py": "print('hello')\n",
    }


def make_project(path: Path, *, configured: bool = True) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    (path / "pm-project.json").write_text(json.dumps({
        "format_version": 1,
        "name": "Test App",
        "description": "test",
        "compose_file": "compose.yaml",
        "env_file": ".pm.env",
        "env_example_file": ".pm.env.example",
        "app_service": "app",
        "required_env": ["BOT_TOKEN", "ADMIN_ID"],
    }), "utf-8")
    (path / "compose.yaml").write_text(
        "services:\n  app:\n    image: python:3.12-slim\n    command: [\"python\", \"-c\", \"import time; time.sleep(3600)\"]\n    env_file:\n      - .pm.env\n", "utf-8"
    )
    (path / ".pm.env.example").write_text("BOT_TOKEN=CHANGE_ME\nADMIN_ID=CHANGE_ME\nLOG_LEVEL=INFO\n", "utf-8")
    (path / ".pm.env").write_text(
        "BOT_TOKEN=real-token\nADMIN_ID=123456\nLOG_LEVEL=INFO\n" if configured else
        "BOT_TOKEN=CHANGE_ME\nADMIN_ID=CHANGE_ME\nLOG_LEVEL=INFO\n", "utf-8"
    )
    (path / ".pm.env").chmod(0o600)
    return path


def test_safe_slug():
    assert main.safe_slug("My Cool Project") == "my-cool-project"
    assert main.safe_slug("../weird/name") == "weird-name"
    assert main.safe_slug("---") == ""


def test_extract_valid_archive(tmp_path):
    archive = tmp_path / "valid.zip"
    make_zip(archive, {"compose.yaml": "services:\n  web:\n    image: nginx:alpine\n", "README.md": "hello"})
    destination = tmp_path / "out"
    main.secure_extract_zip(archive, destination)
    assert (destination / "compose.yaml").is_file()
    assert (destination / "README.md").read_text() == "hello"


def test_extract_rejects_path_traversal(tmp_path):
    archive = tmp_path / "bad.zip"
    make_zip(archive, {"../escape.txt": "nope"})
    with pytest.raises(ValueError):
        main.secure_extract_zip(archive, tmp_path / "out")


def test_extract_rejects_windows_path(tmp_path):
    archive = tmp_path / "bad.zip"
    make_zip(archive, {"..\\escape.txt": "nope"})
    with pytest.raises(ValueError):
        main.secure_extract_zip(archive, tmp_path / "out")


def test_extract_rejects_symlink(tmp_path):
    archive = tmp_path / "bad-link.zip"
    info = zipfile.ZipInfo("escape")
    info.create_system = 3
    info.external_attr = (stat.S_IFLNK | 0o777) << 16
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr(info, "../../etc/passwd")
    with pytest.raises(ValueError, match="ссылки"):
        main.secure_extract_zip(archive, tmp_path / "out")


def test_choose_nested_project_root(tmp_path):
    root = tmp_path / "extracted"
    nested = root / "my-project"
    make_project(nested)
    (nested / ".pm.env").unlink()  # the manager creates this from .pm.env.example
    picked, compose = main.choose_project_root(root)
    assert picked == nested
    assert compose == "compose.yaml"
    assert (nested / ".pm.env").is_file()
    assert (nested / ".pm.env").stat().st_mode & 0o777 == 0o600


def test_parse_compose_ps_json_lines():
    output = '\n'.join([
        json.dumps({"Name": "api", "Service": "api", "State": "running", "Status": "Up"}),
        json.dumps({"Name": "db", "Service": "db", "State": "exited", "Status": "Exited (0)"}),
    ])
    rows = main.parse_compose_ps(output)
    assert len(rows) == 2
    assert rows[0]["state"] == "running"
    assert rows[1]["service"] == "db"


def test_csrf_requires_matching_token():
    class FakeRequest:
        session = {"csrf_token": "right"}
        headers = {}
    with pytest.raises(Exception):
        main.require_csrf(FakeRequest(), "wrong")
    main.require_csrf(FakeRequest(), "right")


def test_login_upload_action_and_logout(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    import re

    monkeypatch.setattr(main, "PROJECTS_DIR", tmp_path / "projects")
    monkeypatch.setattr(main, "DIAGNOSTICS_DIR", tmp_path / "diagnostics")
    main.DIAGNOSTICS_DIR.mkdir()
    monkeypatch.setattr(main, "STARTUP_VERIFY_DELAY_SECONDS", 0)
    monkeypatch.setattr(main, "ADMIN_USERNAME", "admin")
    monkeypatch.setattr(main, "ADMIN_PASSWORD", "test-password")
    main.PROJECTS_DIR.mkdir()
    calls = []

    def fake_run_command(command, cwd, timeout=60):
        calls.append((command, cwd, timeout))
        if "ps" in command:
            return 0, ""
        return 0, "fake compose ok"

    def fake_run_command_to_log(command, cwd, log_path, timeout=300):
        calls.append((command, cwd, timeout))
        with Path(log_path).open("a", encoding="utf-8") as output:
            output.write("fake full command output\n")
        return 0

    def fake_collect_diagnostics(slug, path, log_path):
        main.append_log_section(Path(log_path), "TEST DIAGNOSTICS", "all services running")
        return {"state": "running", "services": [{"service": "web", "state": "running"}], "logs_exit_code": 0}

    monkeypatch.setattr(main, "run_command", fake_run_command)
    monkeypatch.setattr(main, "run_command_to_log", fake_run_command_to_log)
    monkeypatch.setattr(main, "collect_project_diagnostics", fake_collect_diagnostics)
    client = TestClient(main.app)

    login_page = client.get("/login")
    assert login_page.status_code == 200
    token = re.search(r'name="csrf_token" value="([^"]+)"', login_page.text).group(1)
    login_response = client.post("/login", data={"username": "admin", "password": "test-password", "csrf_token": token}, follow_redirects=False)
    assert login_response.status_code == 303

    dashboard = client.get("/")
    assert dashboard.status_code == 200
    csrf = re.search(r'<meta name="csrf-token" content="([^"]+)"', dashboard.text).group(1)

    archive_path = tmp_path / "app.zip"
    make_zip(archive_path, project_files())
    with archive_path.open("rb") as stream:
        upload = client.post(
            "/api/projects",
            data={"name": "Test app"},
            files={"file": ("app.zip", stream, "application/zip")},
            headers={"X-CSRF-Token": csrf},
        )
    assert upload.status_code == 201, upload.text
    assert (main.PROJECTS_DIR / "test-app" / "compose.yaml").exists()
    main.write_environment_file(main.PROJECTS_DIR / "test-app", {"BOT_TOKEN": "real-test-token", "ADMIN_ID": "123456", "LOG_LEVEL": "INFO"})

    action = client.post("/api/projects/test-app/actions/start", headers={"X-CSRF-Token": csrf})
    assert action.status_code == 202
    job_id = action.json()["job_id"]
    # TestClient uses a short-lived event loop per request without lifespan; run
    # the scheduled job explicitly in a stable loop for this unit test.
    import asyncio
    asyncio.run(main.run_job(job_id, "test-app", "start"))
    result = client.get(f"/api/jobs/{job_id}")
    assert result.json()["status"] == "succeeded", result.json()
    assert Path(result.json()["diagnostic_file"]).is_file()
    assert any("up" in command for command, _, _ in calls)

    diagnostics = client.get("/api/projects/test-app/diagnostics")
    assert diagnostics.status_code == 200, diagnostics.text
    assert diagnostics.json()["filename"].endswith(".log")
    assert "Последний полный отчёт сборки/запуска" in diagnostics.json()["preview"]
    download = client.get("/api/projects/test-app/diagnostics/download")
    assert download.status_code == 200
    assert "TEST DIAGNOSTICS" in download.text

    logout = client.post("/logout", data={"csrf_token": csrf}, follow_redirects=False)
    assert logout.status_code == 303


def test_extract_preserves_executable_bit(tmp_path):
    archive = tmp_path / "script.zip"
    info = zipfile.ZipInfo("entrypoint.sh")
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o755) << 16
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr(info, "#!/bin/sh\necho ok\n")
    destination = tmp_path / "out"
    main.secure_extract_zip(archive, destination)
    assert destination.joinpath("entrypoint.sh").stat().st_mode & 0o111


def test_login_rate_limit_after_five_failures():
    from fastapi.testclient import TestClient
    import re

    client = TestClient(main.app)
    main.LOGIN_FAILURES.pop("testclient", None)
    for _ in range(5):
        page = client.get("/login")
        token = re.search(r'name="csrf_token" value="([^"]+)"', page.text).group(1)
        response = client.post("/login", data={"username": "admin", "password": "wrong", "csrf_token": token}, follow_redirects=False)
        assert response.status_code == 303
    page = client.get("/login")
    token = re.search(r'name="csrf_token" value="([^"]+)"', page.text).group(1)
    response = client.post("/login", data={"username": "admin", "password": "wrong", "csrf_token": token}, follow_redirects=False)
    assert response.status_code == 429
    main.LOGIN_FAILURES.pop("testclient", None)


def test_run_command_to_log_captures_stdout_and_stderr(tmp_path):
    import sys

    log_path = tmp_path / "complete.log"
    code = main.run_command_to_log(
        [sys.executable, "-c", "import sys; print('standard output'); print('standard error', file=sys.stderr); print('FULL-BEGIN'); print('x' * 40000); print('FULL-END')"],
        tmp_path,
        log_path,
        10,
    )
    assert code == 0
    content = log_path.read_text("utf-8")
    assert "standard output" in content
    assert "standard error" in content
    assert "FULL-BEGIN" in content and "FULL-END" in content
    assert len(content) > 30000  # the full stream is persisted, not truncated to the UI tail
    assert "Код завершения: 0" in content


def test_parse_compose_ps_includes_container_diagnostics():
    output = json.dumps({
        "ID": "abc123",
        "Name": "pm-demo-web-1",
        "Service": "web",
        "State": "exited",
        "Status": "Exited (1)",
        "Health": "unhealthy",
        "ExitCode": 1,
    })
    rows = main.parse_compose_ps(output)
    assert rows[0]["id"] == "abc123"
    assert rows[0]["health"] == "unhealthy"
    assert rows[0]["exit_code"] == "1"


def test_collect_project_diagnostics_adds_container_logs_and_inspect(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "DIAGNOSTICS_DIR", tmp_path / "diagnostics")
    project = make_project(tmp_path / "demo")
    calls = []

    def fake_run_command(command, cwd, timeout=60):
        calls.append(command)
        if "ps" in command:
            return 0, json.dumps({"ID": "container123", "Name": "web", "Service": "web", "State": "exited", "Status": "Exited (1)"})
        return 0, ""

    def fake_run_command_to_log(command, cwd, log_path, timeout=300):
        calls.append(command)
        with Path(log_path).open("a", encoding="utf-8") as stream:
            stream.write("container log output\\n")
        return 0

    monkeypatch.setattr(main, "run_command", fake_run_command)
    monkeypatch.setattr(main, "run_command_to_log", fake_run_command_to_log)
    report = main.new_diagnostic_file("demo", "test")
    result = main.collect_project_diagnostics("demo", project, report)
    assert result["state"] == "stopped"
    assert any("logs" in command for command in calls)
    assert any(command[:2] == ["docker", "inspect"] for command in calls)
    text = report.read_text("utf-8")
    assert "Полные логи контейнеров" in text
    assert "docker inspect" in text
    assert "container log output" in text


def test_failed_start_persists_diagnostic_report(tmp_path, monkeypatch):
    import asyncio

    project = make_project(tmp_path / "demo")
    monkeypatch.setattr(main, "PROJECTS_DIR", tmp_path)
    monkeypatch.setattr(main, "DIAGNOSTICS_DIR", tmp_path / "diagnostics")
    monkeypatch.setattr(main, "STARTUP_VERIFY_DELAY_SECONDS", 0)

    def fake_run_command_to_log(command, cwd, log_path, timeout=300):
        with Path(log_path).open("a", encoding="utf-8") as stream:
            stream.write("BUILD FAILED: missing dependency\\n")
        return 17

    def fake_collect(slug, path, log_path):
        main.append_log_section(Path(log_path), "TEST LOGS", "container exited")
        return {"state": "stopped", "services": [{"service": "web", "state": "exited"}], "logs_exit_code": 0}

    monkeypatch.setattr(main, "run_command_to_log", fake_run_command_to_log)
    monkeypatch.setattr(main, "collect_project_diagnostics", fake_collect)
    job_id = "diagnostic-test"
    main.JOBS[job_id] = {"id": job_id, "project": "demo", "action": "start", "status": "queued"}
    asyncio.run(main.run_job(job_id, "demo", "start"))
    job = main.JOBS[job_id]
    assert job["status"] == "failed"
    report = Path(job["diagnostic_file"])
    assert report.is_file()
    content = report.read_text("utf-8")
    assert "BUILD FAILED: missing dependency" in content
    assert "container exited" in content


def test_successful_compose_up_but_exited_service_is_failed(tmp_path, monkeypatch):
    import asyncio

    project = make_project(tmp_path / "app")
    monkeypatch.setattr(main, "PROJECTS_DIR", tmp_path)
    monkeypatch.setattr(main, "DIAGNOSTICS_DIR", tmp_path / "diagnostics")
    monkeypatch.setattr(main, "STARTUP_VERIFY_DELAY_SECONDS", 0)
    monkeypatch.setattr(main, "run_command_to_log", lambda command, cwd, log_path, timeout=300: 0)
    monkeypatch.setattr(
        main,
        "collect_project_diagnostics",
        lambda slug, path, log_path: {"state": "stopped", "services": [{"service": "web", "state": "exited"}], "logs_exit_code": 0},
    )
    job_id = "exited-after-success"
    main.JOBS[job_id] = {"id": job_id, "project": "app", "action": "start", "status": "queued"}
    asyncio.run(main.run_job(job_id, "app", "start"))
    assert main.JOBS[job_id]["status"] == "failed"
    assert "не удался" in main.JOBS[job_id]["output"].lower()


def test_diagnostic_pruning_keeps_configured_number(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "DIAGNOSTICS_DIR", tmp_path / "diagnostics")
    monkeypatch.setattr(main, "DIAGNOSTICS_KEEP_PER_PROJECT", 2)
    directory = main.DIAGNOSTICS_DIR / "demo"
    directory.mkdir(parents=True)
    files = []
    for index in range(4):
        path = directory / f"2026010{index}T000000Z_start_{index}.log"
        path.write_text(str(index), "utf-8")
        files.append(path)
    main.prune_diagnostics("demo")
    assert len(list(directory.glob("*.log"))) == 2
    assert (directory / files[-1].name).exists()
    assert (directory / files[-2].name).exists()


def test_strict_project_manifest_and_fixed_files(tmp_path):
    project = make_project(tmp_path / "strict")
    spec = main.validate_project_layout(project)
    assert spec["format_version"] == 1
    command = main.compose_base("strict", project)
    assert command[0:3] == ["docker", "compose", "--env-file"]
    assert ".pm.env" in command
    assert command[-1] == "compose.yaml"
    assert (project / ".pm.env").stat().st_mode & 0o777 == 0o600
    assert ".pm.env" in (project / ".dockerignore").read_text("utf-8")
    assert ".pm.env" in (project / ".gitignore").read_text("utf-8")


def test_strict_project_rejects_legacy_compose_only(tmp_path):
    project = tmp_path / "legacy"
    project.mkdir()
    (project / "docker-compose.yml").write_text("services: {}", "utf-8")
    with pytest.raises(ValueError, match="pm-project.json"):
        main.validate_project_layout(project)


def test_strict_project_rejects_app_service_without_pm_env_file(tmp_path):
    project = make_project(tmp_path / "bad-compose")
    (project / "compose.yaml").write_text(
        "services:\n  app:\n    image: python:3.12-slim\n", "utf-8"
    )
    with pytest.raises(ValueError, match="env_file"):
        main.validate_project_layout(project)


def test_strict_project_rejects_uploaded_private_env(tmp_path):
    archive = tmp_path / "has-secret.zip"
    files = project_files()
    files[".pm.env"] = "BOT_TOKEN=should-not-upload\nADMIN_ID=1\n"
    make_zip(archive, files)
    extracted = tmp_path / "extracted"
    main.secure_extract_zip(archive, extracted)
    with pytest.raises(ValueError, match="Не добавляй .pm.env"):
        main.choose_project_root(extracted)


def test_environment_file_roundtrip_preserves_special_characters(tmp_path):
    project = make_project(tmp_path / "env-roundtrip")
    values = {
        "BOT_TOKEN": "token with spaces $value and 'quote'",
        "ADMIN_ID": "123456",
        "LOG_LEVEL": "INFO",
    }
    main.write_environment_file(project, values)
    assert main.parse_env_file(project / ".pm.env") == values
    assert (project / ".pm.env").stat().st_mode & 0o777 == 0o600


def test_required_environment_identifies_placeholders(tmp_path):
    project = make_project(tmp_path / "required-check", configured=False)
    assert main.required_environment_missing(project) == ["BOT_TOKEN", "ADMIN_ID"]
    main.write_environment_file(project, {"BOT_TOKEN": "real-token", "ADMIN_ID": "98765"})
    assert main.required_environment_missing(project) == []


def test_environment_api_masks_secrets_and_keeps_blank_secret(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    import re

    project = make_project(tmp_path / "demo")
    main.write_environment_file(project, {"BOT_TOKEN": "very-secret-token", "ADMIN_ID": "123456", "LOG_LEVEL": "DEBUG"})
    monkeypatch.setattr(main, "PROJECTS_DIR", tmp_path)
    monkeypatch.setattr(main, "ADMIN_USERNAME", "admin")
    monkeypatch.setattr(main, "ADMIN_PASSWORD", "test-password")
    client = TestClient(main.app)
    login_page = client.get("/login")
    csrf = re.search(r'name="csrf_token" value="([^"]+)"', login_page.text).group(1)
    login_response = client.post(
        "/login",
        data={"username": "admin", "password": "test-password", "csrf_token": csrf},
        follow_redirects=False,
    )
    assert login_response.status_code == 303
    dashboard = client.get("/")
    csrf = re.search(r'<meta name="csrf-token" content="([^"]+)"', dashboard.text).group(1)

    response = client.get("/api/projects/demo/environment")
    assert response.status_code == 200
    data = response.json()
    token = next(item for item in data["variables"] if item["key"] == "BOT_TOKEN")
    assert token["secret"] is True
    assert token["configured"] is True
    assert token["value"] == ""
    assert "very-secret-token" not in response.text

    update = client.put(
        "/api/projects/demo/environment",
        headers={"X-CSRF-Token": csrf},
        json={"variables": [
            {"key": "BOT_TOKEN", "value": "", "keep_existing": True},
            {"key": "ADMIN_ID", "value": "777888"},
            {"key": "LOG_LEVEL", "value": "INFO"},
        ]},
    )
    assert update.status_code == 200, update.text
    assert main.parse_env_file(project / ".pm.env")["BOT_TOKEN"] == "very-secret-token"
    assert main.parse_env_file(project / ".pm.env")["ADMIN_ID"] == "777888"
    assert "very-secret-token" not in update.text


def test_start_job_fails_before_docker_when_required_env_missing(tmp_path, monkeypatch):
    import asyncio

    project = make_project(tmp_path / "missing-env", configured=False)
    monkeypatch.setattr(main, "PROJECTS_DIR", tmp_path)
    monkeypatch.setattr(main, "DIAGNOSTICS_DIR", tmp_path / "diagnostics")
    monkeypatch.setattr(main, "run_command_to_log", lambda *args, **kwargs: pytest.fail("Docker should not be called"))
    job_id = "missing-required-env"
    main.JOBS[job_id] = {"id": job_id, "project": "missing-env", "action": "start", "status": "queued"}
    asyncio.run(main.run_job(job_id, "missing-env", "start"))
    job = main.JOBS[job_id]
    assert job["status"] == "failed"
    assert "BOT_TOKEN" in job["output"] and "ADMIN_ID" in job["output"]
    assert Path(job["diagnostic_file"]).is_file()


def test_invalid_project_preflight_writes_diagnostic_report(tmp_path, monkeypatch):
    import asyncio

    project = make_project(tmp_path / "broken-yaml")
    (project / "compose.yaml").write_text("services: [broken", "utf-8")
    monkeypatch.setattr(main, "PROJECTS_DIR", tmp_path)
    monkeypatch.setattr(main, "DIAGNOSTICS_DIR", tmp_path / "diagnostics")
    job_id = "broken-yaml-start"
    main.JOBS[job_id] = {"id": job_id, "project": "broken-yaml", "action": "start", "status": "queued"}
    asyncio.run(main.run_job(job_id, "broken-yaml", "start"))
    job = main.JOBS[job_id]
    assert job["status"] == "failed"
    report = Path(job["diagnostic_file"])
    assert report.is_file()
    content = report.read_text("utf-8")
    assert "Предварительная проверка проекта" in content
    assert "yaml" in content.lower()


def test_project_format_and_template_download_routes(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    import re

    monkeypatch.setattr(main, "ADMIN_USERNAME", "admin")
    monkeypatch.setattr(main, "ADMIN_PASSWORD", "test-password")
    client = TestClient(main.app)
    page = client.get("/login")
    csrf = re.search(r'name="csrf_token" value="([^"]+)"', page.text).group(1)
    response = client.post(
        "/login",
        data={"username": "admin", "password": "test-password", "csrf_token": csrf},
        follow_redirects=False,
    )
    assert response.status_code == 303
    instruction = client.get("/project-format")
    assert instruction.status_code == 200
    assert "pm-project.json" in instruction.text
    template = client.get("/project-template.zip")
    assert template.status_code == 200
    assert template.headers["content-type"].startswith("application/zip")
    import zipfile
    import io
    with zipfile.ZipFile(io.BytesIO(template.content)) as archive:
        names = set(archive.namelist())
    assert any(name.endswith("/pm-project.json") for name in names)
    assert any(name.endswith("/.pm.env.example") for name in names)


def test_bundled_python_template_matches_manager_format(tmp_path):
    import shutil

    template_source = Path(__file__).parents[1] / "project-template"
    template_copy = tmp_path / "python-template"
    shutil.copytree(template_source, template_copy)
    spec = main.validate_project_layout(template_copy, create_env=True)
    assert spec["app_service"] == "app"
    assert (template_copy / "main.py").is_file()
    assert (template_copy / "Dockerfile").is_file()
    assert main.required_environment_missing(template_copy) == ["BOT_TOKEN", "ADMIN_ID"]
